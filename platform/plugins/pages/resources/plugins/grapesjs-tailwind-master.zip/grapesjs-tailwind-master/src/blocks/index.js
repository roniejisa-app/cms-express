import loadTailwindBlocks from './tailwind'

export default (editor, opts = {}, openBlock) => {
  loadTailwindBlocks(editor, opts, openBlock);
}
