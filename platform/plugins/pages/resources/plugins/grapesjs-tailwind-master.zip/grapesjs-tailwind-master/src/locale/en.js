export default {
    'grapesjs-tailwind': {
        // 'key': 'value',
    },
};